<?php

namespace Users;

class Killbill extends Merchant
{
    public function __construct()
    {
        parent::__construct('killbill','A12345678a');
    }
}