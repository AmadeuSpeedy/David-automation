<?php

namespace Users;

class MerchViktor extends Merchant
{
    public function __construct()
    {
        parent::__construct('merchViktor','A12345678a');
    }
}